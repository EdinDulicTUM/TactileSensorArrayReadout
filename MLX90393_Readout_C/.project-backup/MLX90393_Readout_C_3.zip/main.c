#include <atmel_start.h>
#include <Melexis/MLX90393_microchip.h>
#include <stdio.h>
#include <string.h>
#include <driver_init.h>
#include <math.h>

//struct for I2C IO
struct io_descriptor *bmx_io;
//io descriptor for debug UART
struct io_descriptor *debug_io;

struct MLX90393 sensor1;
struct MLX90393 sensor2;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//Initialize I2C communication
	i2c_m_sync_get_io_descriptor(&I2C_0, &bmx_io);
	i2c_m_sync_enable(&I2C_0);
	
	//enable UART drivers on the virtual com port
	usart_sync_get_io_descriptor(&USART_0, &debug_io);
	usart_sync_enable(&USART_0);

	initialize(&sensor1);
	begin(&sensor1,1,0,1,false, bmx_io);
	delay_ms(10);
	
	initialize(&sensor2);
	begin(&sensor2,1,0,0,false, bmx_io);
	delay_ms(10);


	/* Replace with your application code */
	while (1) {
		
		
		
		
		readData(&sensor1, bmx_io);
		readData(&sensor2, bmx_io);
		
		char str1[120] = {};
		sprintf(str1, "Sensor 1: X=%.2f; Y=%.2f;  Z=%.2f; Temp = %.2f\n", sensor1.data.x, sensor1.data.y, sensor1.data.z, sensor1.data.t);
		io_write(debug_io, (uint8_t *)str1, strlen(str1));
		
		char str2[120] = {};
		sprintf(str2, "Sensor 2: X=%.2f; Y=%.2f;  Z=%.2f; Temp = %.2f\n", sensor2.data.x, sensor2.data.y, sensor2.data.z, sensor2.data.t);
		io_write(debug_io, (uint8_t *)str2, strlen(str2));
		
		delay_ms(1000);
	}
}
