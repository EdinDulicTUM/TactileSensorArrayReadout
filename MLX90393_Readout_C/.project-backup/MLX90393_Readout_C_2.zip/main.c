#include <atmel_start.h>
#include <Melexis/MLX90393_microchip.h>
#include <stdio.h>
#include <string.h>
#include <driver_init.h>
#include <math.h>

//struct for I2C IO
struct io_descriptor *bmx_io;
//io descriptor for debug UART
struct io_descriptor *debug_io;

struct MLX90393 sensor1;

float t = 5;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//Initialize I2C communication
	i2c_m_async_get_io_descriptor(&I2C_0, &bmx_io);
	i2c_m_async_enable(&I2C_0);
	
	//enable UART drivers on the virtual com port
	usart_sync_get_io_descriptor(&USART_0, &debug_io);
	usart_sync_enable(&USART_0);

	initialize(&sensor1);
	begin(&sensor1,1,0,1,false);
	delay_ms(10);


	/* Replace with your application code */
	while (1) {
		
		
		
		
		readData(&sensor1);
		
		char str1[120] = {};
		sprintf(str1, "Sensor 1: X=%.2f; Y=%.2f;  Z=%.2f; Temp = %.2f\n", sensor1.data.x, sensor1.data.y, sensor1.data.z, t);
		io_write(debug_io, (uint8_t *)str1, strlen(str1));
		delay_ms(10);
	}
}
