#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	configure_ethercat_dma_descriptors();
	/* Replace with your application code */
	while (1) {
	}
}
