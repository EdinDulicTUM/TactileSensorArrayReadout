#include <atmel_start.h>
#include <EtherCAT/ethercat_e54.h>

typedef struct  {
	float qw;
	float qx;
	float qy;
	float qz;
} IMU;

typedef struct  {
	uint16_t	status;
	uint16_t	run_mode;
	uint32_t read_joint_position;
	int16_t   read_j_revolution;
	uint16_t  read_revolution;
	uint32_t  read_rel_position;
	uint32_t read_position;
	float  read_Joint_speed;
	float  read_speed;
	float		read_torque;
	float		read_torque_D;
	float		read_i_m;
	float		read_i_q;
	float		read_i_d;
	IMU			IMU0;
} BLDC_ECAT_OUT;


typedef struct  {
	uint16_t control_mode;
	uint16_t	 control_set;
	int32_t desired_position		;
	uint32_t Motor_position_offset	;
	float desired_speed			;
	float Joint_max_speed		;
	float desired_torque		;
	float tau_max				;
	float tau_kp				;
	float tau_kd				;
	uint16_t tau_N				;
	uint16_t tau_Gain			;
	float tau_offset			;
	uint32_t tau_filter			;
	float I_desired				;
	float I_max					;
	float i_kp					;
	float i_ki					;
} BLDC_ECAT_IN;

volatile BLDC_ECAT_OUT* const BLDC_OUT =&ram_buffer[ram_wr_start];
volatile BLDC_ECAT_IN* const BLDC_IN =&ram_buffer[ram_rd_start];

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	configure_ethercat_dma_descriptors();

	/* Replace with your application code */
	while (1) {
	}
}
