#include <atmel_start.h>
#include <EtherCAT/ethercat_e54.h>


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	configure_ethercat_dma_descriptors();
	
volatile uint16_t  *status				=&ram_buffer[ram_wr_start];
volatile uint16_t  *run_mode			=(((uint16_t *)&ram_buffer[ram_wr_start])+1);
volatile uint32_t *read_joint_position	=&ram_buffer[ram_wr_start+1];
volatile int16_t   *read_j_revolution	=&ram_buffer[ram_wr_start+2];
volatile uint16_t  *read_revolution		=(((uint16_t *)&ram_buffer[ram_wr_start+2])+1);
volatile uint32_t  *read_rel_position	=&ram_buffer[ram_wr_start+3];
volatile uint32_t *read_position		=&ram_buffer[ram_wr_start+4];
volatile float  *read_Joint_speed		=&ram_buffer[ram_wr_start+5];
volatile float  *read_speed			=&ram_buffer[ram_wr_start+6];
volatile float  *read_torque			=&ram_buffer[ram_wr_start+7];
volatile float  *read_torque_D		=&ram_buffer[ram_wr_start+8];
volatile float  *read_current_i_m		=&ram_buffer[ram_wr_start+9];
volatile float  *read_current_i_q		=&ram_buffer[ram_wr_start+10];
volatile float  *read_current_i_d		=&ram_buffer[ram_wr_start+11];
volatile float  *IMU_qw				=&ram_buffer[ram_wr_start+12];
volatile float  *IMU_qx				=&ram_buffer[ram_wr_start+13];
volatile float  *IMU_qy				=&ram_buffer[ram_wr_start+14];
volatile float  *IMU_qz				=&ram_buffer[ram_wr_start+15];

//read
volatile	uint16_t *control_mode			=&ram_buffer[ram_rd_start];
static		uint16_t *control_set			=(((uint16_t *)&ram_buffer[ram_rd_start])+1);
static		int32_t *desired_position		=&ram_buffer[ram_rd_start+1];
static		uint32_t *Motor_position_offset	=&ram_buffer[ram_rd_start+2];
static		float *desired_speed			=&ram_buffer[ram_rd_start+3];
static		float *Joint_max_speed			=&ram_buffer[ram_rd_start+4];
static		float *desired_torque			=&ram_buffer[ram_rd_start+5];
static		float *tau_max					=&ram_buffer[ram_rd_start+6];
static		float *tau_kp					=&ram_buffer[ram_rd_start+7];
static		float *tau_kd					=&ram_buffer[ram_rd_start+8];
static		uint16_t *tau_N					=&ram_buffer[ram_rd_start+9];
static		uint16_t *tau_Gain				=(((uint16_t *)&ram_buffer[ram_rd_start+9])+1);
static		float *tau_offset				=&ram_buffer[ram_rd_start+10];
volatile	uint32_t *tau_filter			=&ram_buffer[ram_rd_start+11];
static		float *I_desired				=&ram_buffer[ram_rd_start+12];
static		float *I_max					=&ram_buffer[ram_rd_start+13];
volatile	float *i_kp						=&ram_buffer[ram_rd_start+14];
volatile	float *i_ki						=&ram_buffer[ram_rd_start+15];



	/* Replace with your application code */
	while (1) {
	}
}
